# Governance

We follow the same governance model as MNE-Python described
[here](https://mne.tools/dev/overview/governance.html)
with the exception that the Steering Council and Institutional Partners differ, see below.

## Steering Council

- Alex Gramfort
- Richard Hoechenberger

## Institutional Partners

- [Institut national de recherche en informatique et en automatique](https://www.inria.fr/)
