bids_root = '/tmp'
ch_types = ['meg']
