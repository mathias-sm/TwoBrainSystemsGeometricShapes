::: config.time_frequency_conditions
::: config.time_frequency_freq_min
::: config.time_frequency_freq_max
::: config.time_frequency_cycles
::: config.time_frequency_subtract_evoked
