::: config.contrasts
::: config.decode
::: config.decoding_metric
::: config.decoding_n_splits
::: config.n_boot
