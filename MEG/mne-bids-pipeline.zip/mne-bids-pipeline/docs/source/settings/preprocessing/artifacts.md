???+ info "Good Practice / Advice"
    Have a look at your raw data and train yourself to detect a blink, a heart
    beat and an eye movement.
    You can do a quick average of blink data and check what the amplitude looks
    like.

::: config.reject
::: config.reject_tmin
::: config.reject_tmax
