::: config.find_breaks
::: config.min_break_duration
::: config.t_break_annot_start_after_previous_event
::: config.t_break_annot_stop_before_next_event
