::: config.mri_t1_path_generator
::: config.mri_landmarks_kind
::: config.spacing
::: config.mindist
::: config.source_info_path_update
