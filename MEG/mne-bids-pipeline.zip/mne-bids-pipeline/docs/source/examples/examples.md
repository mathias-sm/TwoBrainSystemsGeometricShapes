You will find on the left a number of examples using publicly available
datasets, mostly taken from [openneuro](https://openneuro.org).

For a first example, see the results obtained with the [MNE sample dataset](ds000248.html).
