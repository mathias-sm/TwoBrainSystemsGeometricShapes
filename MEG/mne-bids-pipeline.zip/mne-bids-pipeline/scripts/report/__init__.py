from . import _01_make_reports
from . import _02_make_reports_average
from . import _03_make_reports_sronly
from . import _04_make_reports_average_sronly

SCRIPTS = (
    _01_make_reports,
    _02_make_reports_average,
    _03_make_reports_sronly,
    _04_make_reports_average_sronly,
)
