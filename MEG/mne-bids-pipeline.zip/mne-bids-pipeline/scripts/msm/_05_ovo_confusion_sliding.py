"""
=====================
07. Sliding estimator
=====================

A sliding estimator fits a logistic regression model for every time point.
The end result is an averaging effect across sensors.
"""

###############################################################################
# Let us first import the libraries

import os.path as op
import logging
from typing import Optional
import itertools

import numpy as np
import pandas as pd
from scipy.io import savemat

import mne
from mne.utils import BunchConst
from mne.parallel import parallel_func
from mne.minimum_norm import (make_inverse_operator, apply_inverse, read_inverse_operator)
from mne.decoding import GeneralizingEstimator, cross_val_multiscore

from sklearn.model_selection import StratifiedKFold

from mne_bids import BIDSPath

from tqdm import tqdm

from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression

import config
from config import gen_log_kwargs, on_error, failsafe_run

from sklearn.metrics import roc_auc_score

from scipy.ndimage import uniform_filter1d

logger = logging.getLogger('mne-bids-pipeline')


@failsafe_run(on_error=on_error, script_path=__file__)
def run_time_decoding(*, cfg, subject, condition, session=None):
    msg = f'Contrasting conditions: {condition}'
    logger.info(**gen_log_kwargs(message=msg, subject=subject,
                                 session=session))

    fname_epochs = BIDSPath(subject=subject,
                            session=session,
                            task=cfg.task,
                            acquisition=cfg.acq,
                            run=None,
                            recording=cfg.rec,
                            space=cfg.space,
                            suffix='epo',
                            extension='.fif',
                            processing="clean+meta",
                            datatype=cfg.datatype,
                            root=cfg.deriv_root,
                            check=False)

    epochs = mne.read_epochs(fname_epochs)
    epochs.apply_proj()

    # We define the epochs and the labels
    epochs = epochs[condition]

    runs = epochs.metadata["run"].values

    X = epochs.get_data("mag")
    y = epochs.events[:, 2]

    classes = [x for _, x in enumerate(set(y))]
    rev_id = {k:e for e,k in epochs.event_id.items()}

    confusion = np.zeros((len(classes), len(classes), X.shape[2], X.shape[2]))

    for idx1, class1 in enumerate(cfg.shapes):
        for idx2 in range(idx1+1, len(cfg.shapes)):
            class2 = cfg.shapes[idx2]

            print(f"Computing {class1} vs {class2}")

            id_class1 = epochs.event_id["shape/"+class1+"/reference"]
            id_class2 = epochs.event_id["shape/"+class2+"/reference"]

            filt = np.array([x in [id_class1, id_class2] for x in y])

            l_X = X.copy()[filt, :, :]
            l_y = y.copy()[filt]

            l_runs = runs[filt] # Warnings: run start at 1 :'-(
            even = [x in [1, 3, 5, 7] for x in l_runs]
            odd = [x in [2, 4, 6, 8] for x in l_runs]
            peven = [x in [1, 2, 5, 6] for x in l_runs]
            podd = [x in [3, 4, 7, 8] for x in l_runs]
            fhalf = [x in [1, 2, 3, 4] for x in l_runs]
            shalf = [x in [5, 6, 7, 8] for x in l_runs]
            cv = [(even,odd), (odd,even), (peven,podd), (podd,peven), (fhalf,shalf), (shalf,fhalf)]

            clf = make_pipeline(StandardScaler(), LogisticRegression(solver='liblinear'))

            # Replace this with generalizing if need be. Then add 1 dim to
            # confusion and tadaaa
            time_decod = GeneralizingEstimator(clf, n_jobs=cfg.n_jobs, scoring='roc_auc', verbose=False)

            scores = cross_val_multiscore(time_decod, l_X, l_y, cv=cv, n_jobs=cfg.n_jobs, verbose=False)
            confusion[idx1, idx2, :, :] = np.mean(scores, axis=0)
            confusion[idx2, idx1, :, :] = confusion[idx1, idx2, :, :]

    fname_npy = fname_epochs.copy().update(suffix='confusionPerTime+ovo+unsmoothed',
                                           processing=condition,
                                           root=config.msm_deriv_root,
                                           extension='.npy')
    np.save(fname_npy, confusion)


def get_config(
    subject: Optional[str] = None,
    session: Optional[str] = None
) -> BunchConst:
    cfg = BunchConst(
        task=config.get_task(),
        datatype=config.get_datatype(),
        acq=config.acq,
        rec=config.rec,
        space=config.space,
        deriv_root=config.msm_deriv_root,
        conditions=config.conditions,
        contrasts=config.contrasts,
        decode=config.decode,
        decoding_metric=config.decoding_metric,
        decoding_n_splits=config.decoding_n_splits,
        random_state=config.random_state,
        shapes=config.shapes,
        analyze_channels=config.analyze_channels,
        ch_types=config.ch_types,
        eeg_reference=config.get_eeg_reference(),
        n_jobs=config.get_n_jobs()
    )
    return cfg


def main():
    """Run sliding estimator."""
    if not config.multiclass_contrasts:
        msg = 'No contrasts specified; not performing decoding.'
        logger.info(**gen_log_kwargs(message=msg))
        return

    if not config.decode:
        msg = 'No decoding requested by user.'
        logger.info(**gen_log_kwargs(message=msg))
        return

    parallel, run_func, _ = parallel_func(run_time_decoding,
                                          n_jobs=1)
    logs = parallel(
        run_func(cfg=get_config(), subject=subject,
                 condition=cond,
                 session=session)
        for subject, session, cond in
        itertools.product(config.get_subjects(),
                          config.get_sessions(),
                          config.multiclass_contrasts)
    )

    config.save_logs(logs)


if __name__ == '__main__':
    main()
