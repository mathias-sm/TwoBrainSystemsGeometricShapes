"""
====================
03. add metadata to epochs
====================
"""

import itertools
import logging
from typing import Optional
from types import SimpleNamespace

import mne
from mne_bids import BIDSPath

import pandas as pd

import config
from config import make_epochs, gen_log_kwargs, on_error, failsafe_run
from config import parallel_func

logger = logging.getLogger('mne-bids-pipeline')


@failsafe_run(on_error=on_error, script_path=__file__)
def run_epochs(*, cfg, subject, session=None):
    """Extract epochs for one subject."""
    epochs_fname = BIDSPath(subject=subject,
                         session=session,
                         task=cfg.task,
                         acquisition=cfg.acq,
                         recording=cfg.rec,
                         space=cfg.space,
                         extension='.fif',
                         datatype=cfg.datatype,
                         suffix='epo',
                         processing='clean',
                         root=cfg.deriv_root,
                         check=False)

    cplx_theory = {}
    for s in cfg.shapes:
        cplx_theory[s] = {}
        for out in range(5):
            v = cfg.simple_theory.loc[(cfg.simple_theory["name"]==s) & (cfg.simple_theory["out_type"]==out)]["distances"].values[0]
            cplx_theory[s][out] = v

    e = mne.read_epochs(epochs_fname)

    root = f"{cfg.bids_root}/sub-{subject}/meg/sub-{subject}_task-POGS"
    dfs = []
    for r in range(1, 9):
        run = f"run-{r:02}"
        try:
            df = pd.read_csv(f"{root}_{run}_events.tsv", sep="\t")
            df["run"] = r
            dfs.append(df)
        except FileNotFoundError:
            msg = f"Subject {subject} has no run {run}"
            logger.info(**gen_log_kwargs(message=msg, subject=subject,
                                         session=session))

    d = pd.concat(dfs)

    d["base_shape"] = [x.split("/")[1] for x in d["trial_type"]]
    local_acc = 0
    last_s = d["base_shape"].iloc[0]
    acc_l = [0]
    for this_s in d["base_shape"].iloc[1:].values:
        if last_s == this_s:
            local_acc = local_acc + 1
            if local_acc > 29: # We went over a run here!
                local_acc = 0
        else:
            local_acc = 0
        last_s = this_s
        acc_l.append(local_acc)

    d["is_outlier"] = [x.split("/")[2] != "reference" for x in d["trial_type"]]
    d["outlier_type"] = [int(x.split("/")[3]) if len(x.split("/"))>3 else 0 for x in d["trial_type"]]
    d["number_props"] = [int(cplx_theory[x][d["outlier_type"].values[i]]) for i, x in enumerate(d["base_shape"])]
    d["delta_prop"] = [int(cplx_theory[x][0] - cplx_theory[x][d["outlier_type"].values[i]]) for i, x in enumerate(d["base_shape"])]
    d["number_props_ref"] = [int(cplx_theory[x][0]) for i, x in enumerate(d["base_shape"])]
    d["trial_number_from_run"] = d.index
    d["trial_number_from_miniblock"] = acc_l
    d["is_early"] = ["early" if x else "late" for x in (d["trial_number_from_miniblock"] < 6)]
    e.metadata = d.iloc[e.selection].copy()
    e.metadata["trial_number_from_start"] = e.selection
    e.metadata["intercept"] = 1
    e.metadata.drop(["duration", "value", "sample", "onset"], axis=1, inplace=True)

    fname_out = epochs_fname.copy().update(processing='clean+meta', root=cfg.msm_deriv_root)
    e.save(fname_out, overwrite=True)


def get_config(
    subject: Optional[str] = None,
    session: Optional[str] = None
) -> SimpleNamespace:
    cfg = SimpleNamespace(
        process_er=config.process_er,
        runs=config.get_runs(subject=subject),
        use_maxwell_filter=config.use_maxwell_filter,
        proc=config.proc,
        task=config.get_task(),
        datatype=config.get_datatype(),
        session=session,
        acq=config.acq,
        rec=config.rec,
        space=config.space,
        bids_root=config.get_bids_root(),
        deriv_root=config.get_deriv_root(),
        msm_deriv_root=config.get_msm_deriv_root(),
        shapes=config.shapes,
        simple_theory=config.simple_theory,
    )
    return cfg


def main():
    """Run epochs."""
    with config.get_parallel_backend():
        parallel, run_func, _ = parallel_func(
            run_epochs,
            n_jobs=config.get_n_jobs()
        )
        logs = parallel(
            run_func(
                cfg=get_config(subject, session), subject=subject,
                session=session
            )
            for subject, session in
            itertools.product(config.get_subjects(), config.get_sessions())
        )

        config.save_logs(logs)


if __name__ == '__main__':
    main()
