"""
=====================
07. Sliding estimator
=====================

A sliding estimator fits a logistic regression model for every time point.
The end result is an averaging effect across sensors.
"""

###############################################################################
# Let us first import the libraries

import os.path as op
import logging
from typing import Optional
import itertools

import numpy as np
import pandas as pd
from scipy.io import savemat

import mne
from mne.utils import BunchConst
from mne.parallel import parallel_func
from mne.decoding import  SlidingEstimator, get_coef, LinearModel

from sklearn.model_selection import StratifiedKFold

from mne_bids import BIDSPath

from tqdm import tqdm

from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression

import config
from config import gen_log_kwargs, on_error, failsafe_run

from sklearn.metrics import roc_auc_score

import pickle

logger = logging.getLogger('mne-bids-pipeline')


@failsafe_run(on_error=on_error, script_path=__file__)
def run_time_decoding(*, cfg, subject, condition, session=None):
    msg = f'Contrasting conditions: {condition}'
    logger.info(**gen_log_kwargs(message=msg, subject=subject,
                                 session=session))

    fname_epochs = BIDSPath(subject=subject,
                            session=session,
                            task=cfg.task,
                            acquisition=cfg.acq,
                            run=None,
                            recording=cfg.rec,
                            space=cfg.space,
                            suffix='epo',
                            extension='.fif',
                            processing="clean+meta",
                            datatype=cfg.datatype,
                            root=cfg.deriv_root,
                            check=False)
    fname_ave = fname_epochs.copy().update(suffix='ave',
                                           processing="decoding+ovo",
                                           root=config.msm_deriv_root)

    epochs = mne.read_epochs(fname_epochs)
    epochs.apply_proj()

    # We define the epochs and the labels
    epochs = epochs[condition].pick_types(meg=True)

    X = epochs.get_data("meg")
    y = epochs.events[:, 2]

    classes = [x for _, x in enumerate(set(y))]
    rev_id = {k:e for e,k in epochs.event_id.items()}
    # classes_names = [rev_id[x].removesuffix("/reference").removeprefix("shape/") for x in classes]
    classes_names = ['rectangle', 'square', 'isoTrapezoid', 'parallelogram', 'losange', 'kite', 'rightKite', 'rustedHinge', 'hinge', 'trapezoid', 'random']

    all_evoked = []
    for idx1, class1 in enumerate(classes_names):
        for idx2 in range(idx1+1, len(classes_names)):
            class2 = classes_names[idx2]

            id_class1 = epochs.event_id["shape/"+class1+"/reference"]
            id_class2 = epochs.event_id["shape/"+class2+"/reference"]

            filt = np.array([x in [id_class1, id_class2] for x in y])

            l_X = X.copy()[filt, :, :]
            l_y = y.copy()[filt]

            clf = make_pipeline(StandardScaler(), LinearModel(LogisticRegression(solver='liblinear')))
            time_decod = SlidingEstimator(clf, n_jobs=-1, scoring='roc_auc', verbose=True)
            time_decod.fit(l_X, l_y)
            fname_td = fname_epochs.copy().update(suffix='slidest',
                                                  processing=f"{class1}+{class2}",
                                                  root=config.msm_deriv_root,
                                                  extension=".pkl")
            pickle.dump(time_decod, open(fname_td, "wb"))
            coef = get_coef(time_decod, 'patterns_', inverse_transform=True)
            evoked_time_gen = mne.EvokedArray(coef, epochs.info, tmin=epochs.times[0])
            all_evoked.append(evoked_time_gen)

    mne.write_evokeds(fname_ave, all_evoked, overwrite=True)


def get_config(
    subject: Optional[str] = None,
    session: Optional[str] = None
) -> BunchConst:
    cfg = BunchConst(
        task=config.get_task(),
        datatype=config.get_datatype(),
        acq=config.acq,
        rec=config.rec,
        space=config.space,
        deriv_root=config.msm_deriv_root,
        conditions=config.conditions,
        contrasts=config.contrasts,
        decode=config.decode,
        decoding_metric=config.decoding_metric,
        decoding_n_splits=config.decoding_n_splits,
        random_state=config.random_state,
        analyze_channels=config.analyze_channels,
        ch_types=config.ch_types,
        eeg_reference=config.get_eeg_reference(),
        n_jobs=config.get_n_jobs()
    )
    return cfg


def main():
    """Run sliding estimator."""
    if not config.multiclass_contrasts:
        msg = 'No contrasts specified; not performing decoding.'
        logger.info(**gen_log_kwargs(message=msg))
        return

    if not config.decode:
        msg = 'No decoding requested by user.'
        logger.info(**gen_log_kwargs(message=msg))
        return

    parallel, run_func, _ = parallel_func(run_time_decoding,
                                          n_jobs=4)
    logs = parallel(
        run_func(cfg=get_config(), subject=subject,
                 condition=cond,
                 session=session)
        for subject, session, cond in
        itertools.product(config.get_subjects(),
                          config.get_sessions(),
                          config.multiclass_contrasts)
    )

    config.save_logs(logs)


if __name__ == '__main__':
    main()
