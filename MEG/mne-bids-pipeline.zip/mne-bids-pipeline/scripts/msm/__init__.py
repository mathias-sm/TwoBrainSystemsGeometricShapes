from . import _01_add_metadata
from . import _02_sliding_estimator_ref_out
from . import _03_sliding_estimator_ref_out_per_shape
from . import _04_sliding_estimator_ref_out_decode_per_shapes
from . import _05_ovo_confusion_sliding
from . import _06_ovo_confusion_sliding_save_decoder
from . import _07_source_decoder

SCRIPTS = (
    _01_add_metadata,
    _02_sliding_estimator_ref_out,
    _03_sliding_estimator_ref_out_per_shape,
    _04_sliding_estimator_ref_out_decode_per_shapes,
    _05_ovo_confusion_sliding,
    _06_ovo_confusion_sliding_save_decoder,
    _07_source_decoder
)
