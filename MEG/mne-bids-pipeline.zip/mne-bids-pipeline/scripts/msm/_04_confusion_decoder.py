"""
=====================
07. Sliding estimator
=====================

A sliding estimator fits a logistic regression model for every time point.
The end result is an averaging effect across sensors.
"""

###############################################################################
# Let us first import the libraries

import os.path as op
import logging
from typing import Optional
import itertools

import numpy as np
import pandas as pd
from scipy.io import savemat

import mne
from mne.utils import BunchConst
from mne.parallel import parallel_func
from mne.decoding import GeneralizingEstimator, cross_val_multiscore

from mne_bids import BIDSPath

from tqdm import tqdm

from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression

import config
from config import gen_log_kwargs, on_error, failsafe_run

from sklearn.metrics import roc_auc_score

logger = logging.getLogger('mne-bids-pipeline')


@failsafe_run(on_error=on_error, script_path=__file__)
def run_time_decoding(*, cfg, subject, condition, session=None):
    msg = f'Contrasting conditions: {condition}'
    logger.info(**gen_log_kwargs(message=msg, subject=subject,
                                 session=session))

    fname_epochs = BIDSPath(subject=subject,
                            session=session,
                            task=cfg.task,
                            acquisition=cfg.acq,
                            run=None,
                            recording=cfg.rec,
                            space=cfg.space,
                            suffix='epo',
                            extension='.fif',
                            datatype=cfg.datatype,
                            root=cfg.deriv_root,
                            check=False)

    epochs = mne.read_epochs(fname_epochs)
    if cfg.analyze_channels:
        # We special-case the average reference here to work around a situation
        # where e.g. `analyze_channels` might contain only a single channel:
        # `concatenate_epochs` below will then fail when trying to create /
        # apply the projection. We can avoid this by removing an existing
        # average reference projection here, and applying the average reference
        # directly – without going through a projector.
        if 'eeg' in cfg.ch_types and cfg.eeg_reference == 'average':
            epochs.set_eeg_reference('average')
        else:
            epochs.apply_proj()
        epochs.pick(cfg.analyze_channels)

    # We define the epochs and the labels
    epochs = epochs[condition]

    X = epochs.get_data()
    y = epochs.events[:, 2]

    assert(len(y) == 2288)
    train = [round(i/286)%2==0 for i in range(len(y))]
    test = [x==False for x in train]

    # In case of outlier, we want to decode 11 (shapes), not 44, for lack of
    # repetitions...
    if condition == "outlier":
        rev_d = {v: k for k, v in epochs.event_id.items()}
        y = [epochs.event_id[f'{rev_d[x].split("/")[0]}/outlier/1'] for x in y]

    clf = make_pipeline(
        StandardScaler(),
        LogisticRegression(
            solver='liblinear',
            multi_class='auto',
            random_state=cfg.random_state))

    # Compute confusion matrix for each cross-validation fold
    classes = [x for _, x in enumerate(set(y))]
    rev_id = {k:e for e,k in epochs.event_id.items()}
    classes_names = [rev_id[x].removesuffix("/reference") for x in classes]

    confusion_list = []
    for time in tqdm(range(X.shape[2])):
        y_pred = np.zeros((len(y), len(classes)))
        XX = X[:,:,time]
        clf.fit(XX[train], y[train])
        y_pred[test] = clf.predict_proba(XX[test])
        confusion = np.zeros((len(classes), len(classes)))
        for ii, train_class in enumerate(classes):
            for jj in range(ii, len(classes)):
                confusion[ii, jj] = roc_auc_score(y == train_class, y_pred[:, jj])
                confusion[jj, ii] = confusion[ii, jj]
        df = pd.DataFrame(confusion,
                columns=classes_names,
                index=classes_names)
        df["shape1"] = df.index
        df = pd.melt(df, id_vars="shape1", var_name="shape2")
        df["time"] = time
        confusion_list.append(df)

    fname_csv = fname_epochs.copy().update(suffix='confusionPerTime',
                                           processing='reference',
                                           root=config.msm_deriv_root,
                                           extension='.csv')
    print(confusion_list)
    tabular_data = pd.concat(confusion_list)
    tabular_data.to_csv(fname_csv, sep=',', index=False)


def get_config(
    subject: Optional[str] = None,
    session: Optional[str] = None
) -> BunchConst:
    cfg = BunchConst(
        task=config.get_task(),
        datatype=config.get_datatype(),
        acq=config.acq,
        rec=config.rec,
        space=config.space,
        deriv_root=config.get_deriv_root(),
        conditions=config.conditions,
        contrasts=config.contrasts,
        decode=config.decode,
        decoding_metric=config.decoding_metric,
        decoding_n_splits=config.decoding_n_splits,
        random_state=config.random_state,
        analyze_channels=config.analyze_channels,
        ch_types=config.ch_types,
        eeg_reference=config.get_eeg_reference(),
        n_jobs=config.get_n_jobs()
    )
    return cfg


def main():
    """Run sliding estimator."""
    if not config.multiclass_contrasts:
        msg = 'No contrasts specified; not performing decoding.'
        logger.info(**gen_log_kwargs(message=msg))
        return

    if not config.decode:
        msg = 'No decoding requested by user.'
        logger.info(**gen_log_kwargs(message=msg))
        return

    parallel, run_func, _ = parallel_func(run_time_decoding,
                                          n_jobs=1)
    logs = parallel(
        run_func(cfg=get_config(), subject=subject,
                 condition=cond,
                 session=session)
        for subject, session, cond in
        itertools.product(config.get_subjects(),
                          config.get_sessions(),
                          config.multiclass_contrasts)
    )

    config.save_logs(logs)


if __name__ == '__main__':
    main()






condition = "reference"
subject = "09"
task = "POGS"
msg = f'Contrasting conditions: {condition}'

fname_epochs = BIDSPath(subject=subject, task=task, suffix='epo', extension='.fif', datatype="meg", root="./bids_data/derivatives/mne-bids-pipeline", check=False)
fname_epochs

epochs = mne.read_epochs(fname_epochs)
epochs.apply_proj()
epochs.pick("mag")

# We define the epochs and the labels
epochs = epochs[condition].resample(50)

X = epochs.get_data()
y = epochs.events[:, 2]

train = [round(i/286)%2==0 for i in range(len(y))]
test = [x==False for x in train]

from mne.decoding import GeneralizingEstimator, cross_val_multiscore

clf = make_pipeline(StandardScaler(), LogisticRegression( solver='liblinear', multi_class='ovr')

classes = [x for _, x in enumerate(set(y))]
rev_id = {k:e for e,k in epochs.event_id.items()}
classes_names = [rev_id[x].removesuffix("/reference") for x in classes]

confusion_list = []
for time in tqdm(range(X.shape[2])):
    y_pred = np.zeros((len(y), len(classes)))
    XX = X[:,:,time]
    clf.fit(XX[train], y[train])
    y_pred[test] = clf.predict_proba(XX[test])
    confusion = np.zeros((len(classes), len(classes)))
    for ii, train_class in enumerate(classes):
        for jj in range(ii, len(classes)):
            confusion[ii, jj] = roc_auc_score(y == train_class, y_pred[:, jj])
            confusion[jj, ii] = confusion[ii, jj]
    df = pd.DataFrame(confusion,
            columns=classes_names,
            index=classes_names)
    df["shape1"] = df.index
    df = pd.melt(df, id_vars="shape1", var_name="shape2")
    df["time"] = time
    confusion_list.append(df)

fname_csv = fname_epochs.copy().update(suffix='confusionPerTime',
                                       processing='reference',
                                       root=config.msm_deriv_root,
                                       extension='.csv')
print(confusion_list)
tabular_data = pd.concat(confusion_list)
tabular_data.to_csv(fname_csv, sep=',', index=False)
