"""
=====================
07. Sliding estimator
=====================

A sliding estimator fits a logistic regression model for every time point.
The end result is an averaging effect across sensors.
"""

###############################################################################
# Let us first import the libraries

import os.path as op
import logging
from typing import Optional
import itertools

import numpy as np
import pandas as pd
from scipy.io import savemat

import mne
from mne.utils import BunchConst
from mne.parallel import parallel_func
from mne.decoding import GeneralizingEstimator, cross_val_multiscore

from mne_bids import BIDSPath

from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression

import config
from config import gen_log_kwargs, on_error, failsafe_run

logger = logging.getLogger('mne-bids-pipeline')


@failsafe_run(on_error=on_error, script_path=__file__)
def run_time_decoding(*, cfg, subject, condition, session=None):
    msg = f'Contrasting conditions: {condition}'
    logger.info(**gen_log_kwargs(message=msg, subject=subject,
                                 session=session))

    fname_epochs = BIDSPath(subject=subject,
                            session=session,
                            task=cfg.task,
                            acquisition=cfg.acq,
                            run=None,
                            recording=cfg.rec,
                            space=cfg.space,
                            suffix='epo',
                            extension='.fif',
                            datatype=cfg.datatype,
                            root=cfg.deriv_root,
                            check=False)

    epochs = mne.read_epochs(fname_epochs)
    if cfg.analyze_channels:
        # We special-case the average reference here to work around a situation
        # where e.g. `analyze_channels` might contain only a single channel:
        # `concatenate_epochs` below will then fail when trying to create /
        # apply the projection. We can avoid this by removing an existing
        # average reference projection here, and applying the average reference
        # directly – without going through a projector.
        if 'eeg' in cfg.ch_types and cfg.eeg_reference == 'average':
            epochs.set_eeg_reference('average')
        else:
            epochs.apply_proj()
        epochs.pick(cfg.analyze_channels)

    # We define the epochs and the labels
    epochs = epochs[condition].resample(10)

    X = epochs.get_data()
    y = epochs.events[:, 2]

    # In case of outlier, we want to decode 11 (shapes), not 44, for lack of
    # repetitions...
    if condition == "outlier":
        rev_d = {v: k for k, v in epochs.event_id.items()}
        y = [epochs.event_id[f'{rev_d[x].split("/")[0]}/outlier/1'] for x in y]

    classes = set(y)

    clf = make_pipeline(
        StandardScaler(),
        LogisticRegression(
            multi_class="ovr",
            solver='liblinear',
            random_state=cfg.random_state))

    time_gen = GeneralizingEstimator(
        clf, n_jobs=cfg.n_jobs, scoring=cfg.decoding_metric
    )
    scores = cross_val_multiscore(time_gen, X=X, y=y, cv=cfg.decoding_n_splits, n_jobs=cfg.n_jobs)

    print(scores)
    print(scores.shape)
    assert(False)

    # y_pred = np.zeros((len(y), len(classes)))
    # for train, test in 

    confusion = np.zeros(len(classes), len(classes))
    for ii, train_class in enumerate(classes):
        for jj in range(ii, len(classes)):
            confusion[ii, jj] = roc_auc_score(y==train_class, y_pred[:,jj])
            confusion[jj, ii] = confusion[ii, jj]
    print(confusion)

    # let's save the scores now
    a_vs_b = f'{condition}'.replace(op.sep, '')
    processing = f'{a_vs_b}+{cfg.decoding_metric}'
    processing = processing.replace('_', '-').replace('-', '')

    fname_csv = fname_epochs.copy().update(suffix='decoding',
                                           processing=processing,
                                           root=config.msm_deriv_root,
                                           extension='.csv')
    # WARNING!!! Who is test, who is train?
    tabular_data = pd.DataFrame(
        scores.mean(axis=0),
        index=epochs.times,
        columns=epochs.times,
        copy=False
    )
    tabular_data["condition"] = condition
    tabular_data.to_csv(fname_csv, sep=',', index=True)


def get_config(
    subject: Optional[str] = None,
    session: Optional[str] = None
) -> BunchConst:
    cfg = BunchConst(
        task=config.get_task(),
        datatype=config.get_datatype(),
        acq=config.acq,
        rec=config.rec,
        space=config.space,
        deriv_root=config.get_deriv_root(),
        conditions=config.conditions,
        contrasts=config.contrasts,
        decode=config.decode,
        decoding_metric=config.decoding_metric,
        decoding_n_splits=config.decoding_n_splits,
        random_state=config.random_state,
        analyze_channels=config.analyze_channels,
        ch_types=config.ch_types,
        eeg_reference=config.get_eeg_reference(),
        n_jobs=config.get_n_jobs()
    )
    return cfg


def main():
    """Run sliding estimator."""
    if not config.multiclass_contrasts:
        msg = 'No contrasts specified; not performing decoding.'
        logger.info(**gen_log_kwargs(message=msg))
        return

    if not config.decode:
        msg = 'No decoding requested by user.'
        logger.info(**gen_log_kwargs(message=msg))
        return

    # Here we go parallel inside the :class:`mne.decoding.SlidingEstimator`
    # so we don't dispatch manually to multiple jobs.
    parallel, run_func, _ = parallel_func(run_time_decoding,
                                          n_jobs=1)
    logs = parallel(
        run_func(cfg=get_config(), subject=subject,
                 condition=cond,
                 session=session)
        for subject, session, cond in
        itertools.product(config.get_subjects(),
                          config.get_sessions(),
                          config.multiclass_contrasts)
    )

    config.save_logs(logs)


if __name__ == '__main__':
    main()
