"""
=====================
07. Sliding estimator
=====================

A sliding estimator fits a logistic regression model for every time point.
The end result is an averaging effect across sensors.
"""

###############################################################################
# Let us first import the libraries

import os.path as op
import logging
from typing import Optional
import itertools

import numpy as np
import pandas as pd
from scipy.io import savemat

import mne
from mne.utils import BunchConst
from mne.parallel import parallel_func
from mne.decoding import  SlidingEstimator, get_coef, LinearModel
from mne.minimum_norm import (apply_inverse, read_inverse_operator)

from sklearn.model_selection import StratifiedKFold

from mne_bids import BIDSPath

from tqdm import tqdm

from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression

import config
from config import gen_log_kwargs, on_error, failsafe_run

from sklearn.metrics import roc_auc_score

import pickle

logger = logging.getLogger('mne-bids-pipeline')


def vcorrcoef(X,y):
    Xm = np.mean(X,axis=0)
    ym = np.mean(y)
    r_num = np.sum((X-Xm)*(y-ym)[:,None],axis=0)
    r_den = np.sqrt(np.sum((X-Xm)**2,axis=0)*np.sum((y-ym)**2))
    r = r_num/r_den
    return r


@failsafe_run(on_error=on_error, script_path=__file__)
def run_time_decoding(*, cfg, subject, condition, session=None):
    msg = f'Contrasting conditions: {condition}'
    logger.info(**gen_log_kwargs(message=msg, subject=subject,
                                 session=session))

    fname_ave = BIDSPath(subject=subject,
                            session=session,
                            task=cfg.task,
                            acquisition=cfg.acq,
                            run=None,
                            recording=cfg.rec,
                            space=cfg.space,
                            suffix='ave',
                            extension='.fif',
                            processing="decoding+ovo",
                            datatype=cfg.datatype,
                            root=cfg.msm_deriv_root,
                            check=False)

    fname_inv = fname_ave.copy().update(suffix='inv',
                                        processing=None,
                                        root=cfg.deriv_root)

    fname_stcs = fname_ave.copy().update(suffix='stc',
                                         processing="decoding+to+src",
                                         extension='.pkl')

    all_evokeds = mne.read_evokeds(fname_ave)
    inverse_operator = read_inverse_operator(fname_inv)
    stcs = []
    for evo in all_evokeds:
        stc = apply_inverse(evoked=evo, inverse_operator=inverse_operator, method="eLORETA")
        stcs.append(stc)

    stcs = np.array([stc.data for stc in stcs])
    oldshape = stcs.shape

    d_IT = vcorrcoef(stcs.reshape((55,-1)), config.flat_IT).reshape(oldshape[1:])
    d_symb = vcorrcoef(stcs.reshape((55,-1)), config.flat_symb).reshape(oldshape[1:])

    stc_IT = stc.copy()
    stc_IT.data = d_IT
    stc_symb = stc.copy()
    stc_symb.data = d_symb

    pickle.dump([stc_IT, stc_symb], open(fname_stcs, "wb"))


def get_config(
    subject: Optional[str] = None,
    session: Optional[str] = None
) -> BunchConst:
    cfg = BunchConst(
        task=config.get_task(),
        datatype=config.get_datatype(),
        acq=config.acq,
        rec=config.rec,
        space=config.space,
        deriv_root=config.get_deriv_root(),
        msm_deriv_root=config.get_msm_deriv_root(),
        conditions=config.conditions,
        contrasts=config.contrasts,
        decode=config.decode,
        decoding_metric=config.decoding_metric,
        decoding_n_splits=config.decoding_n_splits,
        random_state=config.random_state,
        analyze_channels=config.analyze_channels,
        ch_types=config.ch_types,
        eeg_reference=config.get_eeg_reference(),
        n_jobs=config.get_n_jobs()
    )
    return cfg


def main():
    """Run sliding estimator."""
    if not config.multiclass_contrasts:
        msg = 'No contrasts specified; not performing decoding.'
        logger.info(**gen_log_kwargs(message=msg))
        return

    if not config.decode:
        msg = 'No decoding requested by user.'
        logger.info(**gen_log_kwargs(message=msg))
        return

    parallel, run_func, _ = parallel_func(run_time_decoding,
                                          n_jobs=20)
    logs = parallel(
        run_func(cfg=get_config(), subject=subject,
                 condition=cond,
                 session=session)
        for subject, session, cond in
        itertools.product(config.get_subjects(),
                          config.get_sessions(),
                          config.multiclass_contrasts)
        if subject != "03"
    )

    config.save_logs(logs)


if __name__ == '__main__':
    main()
