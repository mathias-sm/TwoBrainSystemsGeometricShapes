from . import _01_recon_all
from . import _02_coreg_surfaces

SCRIPTS = (
    _01_recon_all,
    _02_coreg_surfaces
)
